---
document_id: 04_leave_policy
organization: Northstar Financial Services Group
policy_name: Leave Policy
category: leave
owner: People & Culture
version: 3.0
effective_date: 2026-01-01
review_cycle: Annual, or earlier if material change occurs
jurisdiction: Global corporate baseline; local law and local employment terms prevail
document_status: Approved evaluation-corpus document
---

# Leave Policy

## 1. Document control and policy intent

This policy is part of the Northstar People & Culture framework. Its purpose is to make decisions predictable, auditable and understandable while allowing managers to apply judgment to the facts of an individual case. A policy sets a baseline; it does not remove the need to consider the employee’s role, business context, local requirements, employment terms, risk profile and any approved adjustments. Managers should avoid creating informal rules that differ from published policy unless an approved exception or local requirement applies.

**Purpose.** Explain how planned and statutory leave requests are made, approved, recorded and managed.

**Owner.** People & Culture.

**Effective date.** 2026-01-01. **Version.** 3.0.

## 2. Scope

This policy applies to Northstar employees unless a local employment term, collective arrangement or applicable law requires a different rule. Contractors and contingent workers may be subject to equivalent requirements through their contract or assignment terms. Managers are responsible for applying the policy within their delegated authority and escalating matters that require specialist review. The policy should be read together with the employee handbook and any specific policy named in the cross-references below.

## 3. Definitions

**Annual Leave.** Paid time away from work taken under the employee's applicable employment terms.

**Protected Leave.** Leave created or protected by applicable law or local employment terms.

**Manager Approval.** A recorded decision by the responsible manager that leave can be taken for the requested period, subject to policy and business requirements.

## 4. Roles and responsibilities

**Employees.** Understand the policy, provide accurate information, meet agreed requirements, raise questions early, and cooperate with approved processes.

**Managers.** Apply the policy consistently, explain decisions, keep material records, protect confidentiality, and involve People & Culture or another control function when the matter is sensitive, complex or outside delegated authority.

**Policy owner (People & Culture).** Maintain the policy, provide guidance, monitor implementation and review material issues or trends.

**Control functions.** Risk, Compliance, Privacy, Security, Payroll, Mobility or Legal may be involved where the subject matter requires specialist oversight.

## 5. Policy requirements

1. Leave should be requested in advance through the HR system where practicable.
2. Managers should approve or decline requests promptly and consistently.
3. Employees should not commit to travel or other non-refundable arrangements until leave is approved.
4. Business continuity, regulatory coverage, team capacity and previously approved leave may be relevant to the timing of approval.
5. Protected or statutory leave must be handled in accordance with applicable local law.
6. Unused leave, carry-forward and expiry are governed by the employee's local terms and applicable law.

## 6. Procedure and decision workflow

Employees are expected to read the policy that governs the situation and raise questions early. A manager should explain the decision criteria, keep the relevant evidence, and record material approvals or refusals. When the matter is sensitive, involves a legal right, affects another employee, or could lead to formal action, People & Culture should be consulted. The goal is a fair process that can be explained later rather than an undocumented decision based on memory or precedent.

1. **Step 1.** Employee submits a leave request with dates and sufficient information for planning.
2. **Step 2.** Manager checks coverage, deadlines, controls and competing leave.
3. **Step 3.** Manager approves, declines with a clear reason, or requests an alternative date.
4. **Step 4.** HR records the decision and relevant leave type.
5. **Step 5.** Changes or cancellations are recorded to maintain an accurate leave balance.

## 7. Exceptions and special cases

Exceptions may be considered only where the policy allows them or where local law, contractual terms or a documented business requirement requires a different approach. The approving manager must record the reason, duration and scope. An exception for one employee does not automatically create an entitlement for others.

## 8. Records, confidentiality and evidence

Records created under this policy should be accurate, relevant and stored in the designated system. Employees and managers should avoid keeping parallel unofficial files that contain sensitive information unless required for a legitimate business reason. Where an issue moves from an informal discussion to a formal process, the record should show what changed, who made the decision, the evidence considered, the action required and the next review point.

Where a decision relies on a request, approval, review, meeting, assessment or investigation, the record should contain the minimum information needed to show what was decided and why. Sensitive personal information should not be copied into general team correspondence unless there is a legitimate need to know. Requests for records should be handled through the approved privacy, records or HR process.

## 9. Monitoring and review

The policy owner may monitor adoption, exceptions, cycle times, recurring issues, appeals, employee feedback and control incidents. Monitoring should be proportionate and must respect privacy and local data-handling requirements. Material trends may lead to updated guidance, manager training, workflow changes or policy revision.

## 10. Operational guidance

- Two members of a critical operations team request the same week. The manager considers service coverage before approving both requests.
- An employee asks for a leave type that may have statutory protections. People & Culture reviews the applicable local rules rather than applying the general annual-leave process automatically.
- An employee cancels approved leave. The cancellation should be recorded so payroll and leave balances remain accurate.

## 11. Policy interpretation and escalation

A policy is most useful when employees can apply it to realistic situations. For that reason, managers should distinguish a rule from an example. An example explains how a rule may operate; it is not automatically a new entitlement or restriction. Where a question is not answered by this document, the employee should use the named escalation route instead of assuming that silence means permission.
For interpretation questions, employees should first contact their manager where appropriate and then People & Culture. Questions involving privacy, security, tax, mobility, regulatory controls or legal rights should be routed to the relevant specialist team. When two policies appear to conflict, the manager should not pick whichever rule is more convenient; the issue should be escalated so the applicable precedence can be documented.

## 12. Related policies

- Sick Leave & Ill Health Policy
- Flexible Working Policy
- Employee Benefits Policy
- Employee Handbook

## 13. Practical questions and answers

**Q: Does this policy create an automatic entitlement?**  
A: No. The answer depends on the specific rule, approval requirement, applicable employment terms and documented circumstances.

**Q: Who should I contact when the rule is unclear?**  
A: Start with the responsible manager where appropriate and involve People & Culture or the named control function for policy interpretation.

**Q: Does an example override the formal rule?**  
A: No. Examples illustrate how a rule may work and do not independently create rights.

**Q: What happens when local law differs?**  
A: The local legal requirement or applicable contractual term prevails to the extent required, with People & Culture support.

**Q: Can an approval be changed later?**  
A: Yes. An arrangement may be reviewed when circumstances or business needs change, subject to the applicable process and fairness requirements.

## 14. Operational note 1
In operating leave policy, managers should first establish the facts and then apply the policy requirement that is actually relevant. For leave planning, that means avoiding assumptions about intent, avoiding comparisons that are not like-for-like, and confirming the employee’s approved arrangement or role requirement before making a decision. A decision that cannot be explained in simple terms is often a signal that additional review is needed.

## 14. Operational note 2
Consistency does not mean treating every employee identically in every circumstance. Under leave policy, consistency means using the same decision criteria, documenting genuine differences, and considering approved adjustments or local requirements where they apply. Managers should record why an exception was accepted or why a request could not be supported so that future decisions can be compared fairly without creating an accidental precedent.

## 14. Operational note 3
Where a matter overlaps with another policy, the manager should identify the primary process and then coordinate rather than running two contradictory processes. The purpose of the cross-reference section in leave policy is to show which neighbouring policy may hold the detailed rule. People & Culture can help determine sequencing, ownership, and whether the same facts need to be recorded once or in more than one approved system.

## 14. Operational note 4
Employees are responsible for giving accurate information, meeting stated deadlines, and raising changed circumstances promptly. Managers are responsible for making reasonable decisions, communicating them clearly, protecting confidentiality, and escalating matters that are outside their delegated authority. These responsibilities are especially important when leave planning affects customers, regulators, critical operations, or the security of company information.

## 14. Operational note 5
In operating leave policy, managers should first establish the facts and then apply the policy requirement that is actually relevant. For leave planning, that means avoiding assumptions about intent, avoiding comparisons that are not like-for-like, and confirming the employee’s approved arrangement or role requirement before making a decision. A decision that cannot be explained in simple terms is often a signal that additional review is needed.

## 14. Operational note 6
Consistency does not mean treating every employee identically in every circumstance. Under leave policy, consistency means using the same decision criteria, documenting genuine differences, and considering approved adjustments or local requirements where they apply. Managers should record why an exception was accepted or why a request could not be supported so that future decisions can be compared fairly without creating an accidental precedent.

## 14. Operational note 7
Where a matter overlaps with another policy, the manager should identify the primary process and then coordinate rather than running two contradictory processes. The purpose of the cross-reference section in leave policy is to show which neighbouring policy may hold the detailed rule. People & Culture can help determine sequencing, ownership, and whether the same facts need to be recorded once or in more than one approved system.

## 14. Operational note 8
Employees are responsible for giving accurate information, meeting stated deadlines, and raising changed circumstances promptly. Managers are responsible for making reasonable decisions, communicating them clearly, protecting confidentiality, and escalating matters that are outside their delegated authority. These responsibilities are especially important when leave planning affects customers, regulators, critical operations, or the security of company information.

## 14. Operational note 9
In operating leave policy, managers should first establish the facts and then apply the policy requirement that is actually relevant. For leave planning, that means avoiding assumptions about intent, avoiding comparisons that are not like-for-like, and confirming the employee’s approved arrangement or role requirement before making a decision. A decision that cannot be explained in simple terms is often a signal that additional review is needed.

## 14. Operational note 10
Consistency does not mean treating every employee identically in every circumstance. Under leave policy, consistency means using the same decision criteria, documenting genuine differences, and considering approved adjustments or local requirements where they apply. Managers should record why an exception was accepted or why a request could not be supported so that future decisions can be compared fairly without creating an accidental precedent.

## 14. Operational note 11
Where a matter overlaps with another policy, the manager should identify the primary process and then coordinate rather than running two contradictory processes. The purpose of the cross-reference section in leave policy is to show which neighbouring policy may hold the detailed rule. People & Culture can help determine sequencing, ownership, and whether the same facts need to be recorded once or in more than one approved system.

## 14. Operational note 12
Employees are responsible for giving accurate information, meeting stated deadlines, and raising changed circumstances promptly. Managers are responsible for making reasonable decisions, communicating them clearly, protecting confidentiality, and escalating matters that are outside their delegated authority. These responsibilities are especially important when leave planning affects customers, regulators, critical operations, or the security of company information.

## 14. Operational note 13
In operating leave policy, managers should first establish the facts and then apply the policy requirement that is actually relevant. For leave planning, that means avoiding assumptions about intent, avoiding comparisons that are not like-for-like, and confirming the employee’s approved arrangement or role requirement before making a decision. A decision that cannot be explained in simple terms is often a signal that additional review is needed.

## 15. Version history
- 3.0 — 2026-01-01 — Evaluation corpus baseline; policy owner: People & Culture.
- Prior versions are not represented in this corpus unless explicitly included as a separate document.
